require 'test_helper'

class NewControllerDecoratorTest < Draper::TestCase
end
