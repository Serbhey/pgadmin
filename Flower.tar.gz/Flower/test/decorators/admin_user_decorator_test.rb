require 'test_helper'

class AdminUserDecoratorTest < Draper::TestCase
end
