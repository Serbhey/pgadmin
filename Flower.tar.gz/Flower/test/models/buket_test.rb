require 'test_helper'

class BuketTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
