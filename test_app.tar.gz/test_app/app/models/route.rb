class Route < ApplicationRecord
has_one :driver, :car
end
