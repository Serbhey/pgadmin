
class Item < ApplicationRecord
end
