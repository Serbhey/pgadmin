class RoutePoint < ApplicationRecord
end
