require 'test_helper'

class RoutePointTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
